<!DOCTYPE html>
<html lang="en">
<head>
<title>Document</title>
</head>
<body class="container">
<p class="text-center"><h1>Registro de Alumnos </h1></p>
    <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>" method="post">
    Clave del Alumno:
    <input type="text" name="Clave del Alumno" maxlength="50"><br><br>
    Nombre:
    <input type="text" name="Nombre" maxlength="50"><br><br>
    Apellidos:
    <input type="text" name="Apellidos" maxlength="50"><br><br>
    Email:
    <input type="text" name="Email" maxlength="50"><br><br>
    Direccion:
    <input type="text" name="Direccion" maxlength="50"><br><br>
    Curp:
    <input type="text" name="Curp" maxlength="50"><br><br>
    Carrera:
    <select name="Carrera">
        <option value="Administracion"> Administracion</option>
        <option value="Electromecanica">Electromecanica</option>
        <option value="Industrial">Industrial</option>
        <option value="Sistemas">Sistemas Computacionales</option>
    </select><br><br>

    

<input type="submit"  name="submit" value="enviar"><br>
    
    
    

</form>
    </body>
    
    <form action="RegistroAlumnos.php" method="POST">
    <?php 

                $Administracion = "";
                $Electromecanica= "";
                $Industrial= "";
                $Sistemas = "";
        
        
        if(isset($_POST["Administracion"])){
            echo "Bienvenidos al semestre 2021, es un";
        }
    
        elseif($Electromecanica == $Electromecanica){
            echo "Bienvenidos al semestre 2021, es un placer tenerte como alumno de la carrera de Electromecanica, tu coordinador es: ********, favor de presentate con el para mas datos";
        }

        elseif($Industrial == $Industrial){
            echo "Bienvenidos al semestre 2021, es un";
        }

        elseif($Sistemas == $Sistemas){
            echo "Bienvenidos al semestre 2021, es un";
        }
    
 
?>
</form>
</html>